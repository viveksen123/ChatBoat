import{A as c,e as t}from"./mermaid-parser.core.B5sqkMfy.js";export{c as ArchitectureModule,t as createArchitectureServices};
//# sourceMappingURL=architecture-I3QFYML2.DCrAwz7a.js.map
