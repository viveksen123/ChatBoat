import{Z as e,_ as n}from"../chunks/2.DbP0nldR.js";export{e as component,n as universal};
//# sourceMappingURL=2.DHue0_ws.js.map
